/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

/**
 *
 * @author Rafael
 */
import java.sql.*;
import conexao.Conexao;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Vendas;
/**
 *
 * @author Rafael
 */

public class VendasDAO {
    
private List<Vendas> vendas = new ArrayList<Vendas>();
    
    public void inserirVendas(Vendas vendas){
        
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
                
        try {
            stmt = con.prepareStatement("INSERT INTO vendas (cod_venda, idfk_clientes, total, datahora) VALUES (?,?,?,?)");
            stmt.setInt(1, vendas.getCod_vendas());
            stmt.setInt(2, vendas.getIdfk_clientes());
            stmt.setFloat(3, vendas.getTotal());
            stmt.setTimestamp(4, new java.sql.Timestamp(vendas.getDatahora().getTime()));

            stmt.executeUpdate();
            
            System.out.println("Venda inserida!");        
        } catch (SQLException ex) {
            System.out.println("Erro!"+ex); 
        }
    }
    
    // Topico 3 exercicio 3 ---- quantidade de venda em 2020 agrupada por cliente
    
    public List<Vendas> ListarVendas(){
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Vendas> venList = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT idfk_clientes, count(cod_venda) as cod_venda FROM vendas WHERE Year(datahora) = Year('2020') group by idfk_clientes;");
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                Vendas ven = new Vendas();
                
                ven.setIdfk_clientes(rs.getInt("idfk_clientes"));
                ven.setCod_vendas(rs.getInt("cod_venda"));
                
                venList.add(ven);
                
            }
          
        } catch (SQLException ex) {

        } finally {
            Conexao.closeConnection(con, stmt, rs);
        }
        
        return venList;
    }  
    
    // Topico 4 exercicio 3 ---- Listagem de vendas (contendo o valor total da mesma).
    
    public List<Vendas> ListarVendasTotal(){
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Vendas> venList = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("SELECT * FROM vendas");
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                Vendas ven = new Vendas();
                
                ven.setCod_vendas(rs.getInt("cod_venda"));
                ven.setIdfk_clientes(rs.getInt("idfk_clientes"));
                ven.setTotal(rs.getFloat("total"));
                ven.setDatahora(rs.getTimestamp("datahora"));
                venList.add(ven);
                
            }
          
        } catch (SQLException ex) {

        } finally {
            Conexao.closeConnection(con, stmt, rs);
        }
        
        return venList;
    } 
    
    
   
    
}
