package dao;

import java.sql.*;
import conexao.Conexao;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Cliente;
/**
 *
 * @author Rafael
 */

public class ClienteDAO {
 

    public void inserirCliente(Cliente cli){
        
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
                
        try {
            stmt = con.prepareStatement("INSERT INTO clientes (cod_cli, nome, data_nasc, endereco, telefone, e_mail) VALUES (?,?,?,?,?,?)");
            stmt.setInt(1, cli.getCodigo());
            stmt.setString(2, cli.getNome());
            stmt.setTimestamp(3, new java.sql.Timestamp(cli.getNascimento().getTime()));
            stmt.setString(4, cli.getEndereco());
            stmt.setString(5, cli.getTelefone());
            stmt.setString(6, cli.getEmail());

            stmt.executeUpdate();
            
            System.out.println("Cliente inserido!");        
        } catch (SQLException ex) {
            System.out.println("Erro!"+ex); 
        }
    }
    
    //Topico 1 exercicio 3 ---- Listar clientes sem email (null)

    public List<Cliente> ListarCliente(){
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Cliente> cliList = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("select * from clientes where e_mail is NULL");
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                Cliente cli = new Cliente();
                
                cli.setCodigo(rs.getInt("cod_cli"));
                cli.setNome(rs.getString("nome"));
                cli.setNascimento(rs.getDate("data_nasc"));
                cli.setEndereco(rs.getString("endereco"));
                cli.setTelefone(rs.getString("telefone"));
                cli.setEmail(rs.getString("e_mail"));
                
                cliList.add(cli);
                
            }
          
        } catch (SQLException ex) {

        } finally {
            Conexao.closeConnection(con, stmt, rs);
        }
        
        return cliList;
    }

    
 
    
    
    
    
}