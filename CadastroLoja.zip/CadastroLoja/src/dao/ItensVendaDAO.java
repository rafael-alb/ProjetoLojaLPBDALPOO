package dao;

import java.sql.*;
import conexao.Conexao;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.ItensVenda;
import models.Produtos;
import models.Vendas;
/**
 *
 * @author Rafael
 */

public class ItensVendaDAO {
        
    public void inserirItensVenda(ItensVenda itve){
        
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
                
        try {
            stmt = con.prepareStatement("INSERT INTO itens_venda (idfk_vendas, idfk_produtos, quantidade, sub_total) VALUES (?,?,?,?)");
            stmt.setInt(1, itve.getIdfk_vendas().getCod_vendas());
            stmt.setInt(2, itve.getIdfk_produtos().getCod_prod());
            stmt.setInt(3, itve.getQuantidade());
            stmt.setFloat(4, itve.getSub_total());

            stmt.executeUpdate();
            
            System.out.println("item inserido!");        
        } catch (SQLException ex) {
            System.out.println("Erro!"+ex); 
        }
    }

    
    
    
}