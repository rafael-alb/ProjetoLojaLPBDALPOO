package dao;

import java.sql.*;
import conexao.Conexao;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Produtos;
/**
 *
 * @author Rafael
 */

public class ProdutosDAO {
    
private List<Produtos> pd = new ArrayList<Produtos>();
    
    public void inserirProdutos(Produtos pd){
        
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
                
        try {
            stmt = con.prepareStatement("INSERT INTO produtos (cod_prod, descricao, data_validade, estoque, idfk_dist, preco_venda, preco_custo) VALUES (?,?,?,?,?,?,?)");
            stmt.setInt(1, pd.getCod_prod());
            stmt.setString(2, pd.getDescricao());
            stmt.setTimestamp(3, new java.sql.Timestamp(pd.getData_validade().getTime()));
            stmt.setString(4, pd.getEstoque());
            stmt.setInt(5, pd.getIdfk_dist());
            stmt.setFloat(6, pd.getPreco_venda());
            stmt.setFloat(7, pd.getPreco_custo());

            stmt.executeUpdate();
            
            System.out.println("Produto inserido!");        
        } catch (SQLException ex) {
            System.out.println("Erro!"+ex); 
        }
    }
    
    // Tópico 2 do exercicio 3 ---- Listar os produtos vencidos
    
    public List<Produtos> ListarProdutos(){
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        List<Produtos> prodList = new ArrayList<>();
        
        try {
            stmt = con.prepareStatement("select * from produtos where data_validade<CURRENT_TIMESTAMP");
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                Produtos prod = new Produtos();
                
                prod.setCod_prod(rs.getInt("cod_prod"));
                prod.setDescricao(rs.getString("descricao"));
                prod.setData_validade(rs.getDate("data_validade"));
                prod.setEstoque(rs.getString("estoque"));
                prod.setIdfk_dist(rs.getInt("idfk_dist"));
                prod.setPreco_venda(rs.getFloat("preco_venda"));
                prod.setPreco_custo(rs.getFloat("preco_custo"));
                
                prodList.add(prod);
                
            }
          
        } catch (SQLException ex) {

        } finally {
            Conexao.closeConnection(con, stmt, rs);
        }
        
        return prodList;
    }

    
 
    
    
    
    
}