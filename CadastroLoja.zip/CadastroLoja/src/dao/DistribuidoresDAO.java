package dao;

import java.sql.*;
import conexao.Conexao;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import models.Distribuidores;
/**
 *
 * @author Rafael
 */

public class DistribuidoresDAO {
        
    public void inserirDistribuidor(Distribuidores dist){
        
        
        Connection con = Conexao.criarConexao();
        PreparedStatement stmt = null;
                
        try {
            stmt = con.prepareStatement("INSERT INTO distribuidores (cod_dist, nome_fantasia, razao_social, telefone, e_mail) VALUES (?,?,?,?,?)");
            stmt.setInt(1, dist.getCodigo());
            stmt.setString(2, dist.getNome_fantasia());
            stmt.setString(3, dist.getRazao_social());
            stmt.setString(4, dist.getTelefone());
            stmt.setString(5, dist.getEmail());

            stmt.executeUpdate();
            
            System.out.println("Distribuidor inserido!");        
        } catch (SQLException ex) {
            System.out.println("Erro!"); 
        }
    }
    
}