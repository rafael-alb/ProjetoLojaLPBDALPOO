/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Rafael
 */
public class ItensVenda {
    
    public Vendas idfk_vendas;
    public Produtos idfk_produtos;
    public int quantidade;
    public Float sub_total;

    public ItensVenda() {
        
    }

    public Vendas getIdfk_vendas() {
        return idfk_vendas;
    }

    public void setIdfk_vendas(Vendas idfk_vendas) {
        this.idfk_vendas = idfk_vendas;
    }

    public Produtos getIdfk_produtos() {
        return idfk_produtos;
    }

    public void setIdfk_produtos(Produtos idfk_produtos) {
        this.idfk_produtos = idfk_produtos;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public Float getSub_total() {
        return sub_total;
    }

    public void setSub_total(Float sub_total) {
        this.sub_total = sub_total;
    }
    
    public ItensVenda(Vendas idfk_vendas, Produtos idfk_produtos, Integer quantidade, Float sub_total){
            this.idfk_vendas = idfk_vendas;
            this.idfk_produtos = idfk_produtos;
            this.quantidade = quantidade;
            this.sub_total = quantidade*idfk_produtos.getPreco_venda();
    }
    
    
}
