/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author Rafael
 */
public class Distribuidores {
    
    public int codigo;
    public String nome_fantasia;
    public String razao_social;
    public String telefone;
    public String email;

    public Distribuidores() {
       
    }


    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome_fantasia() {
        return nome_fantasia;
    }

    public void setNome_fantasia(String nome_fantasia) {
        this.nome_fantasia = nome_fantasia;
    }

    public String getRazao_social() {
        return razao_social;
    }

    public void setRazao_social(String razao_social) {
        this.razao_social = razao_social;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public Distribuidores(Integer codigo, String nome_fantasia, String razao_social, String telefone, String email){
            this.codigo = codigo;
            this.nome_fantasia = nome_fantasia;
            this.razao_social = razao_social;
            this.telefone = telefone;
            this.email = email;
    }
    
}
