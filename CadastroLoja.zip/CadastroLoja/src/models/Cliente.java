/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Rafael
 */
public class Cliente {

    /**
     * @param codigo
     * @return the codigo
     */

    
    
    public int codigo;
    
    public String nome;
    
    public String endereco;
    
    public String telefone;
    
    public Date nascimento;
    
    public String email;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Date getNascimento() {
        return nascimento;
    }

    public void setNascimento(Date nascimento) {
        this.nascimento = nascimento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
     
    public Cliente(Integer codigo, String nome, Date nascimento, String endereco, String telefone, String email){
            this.codigo = codigo;
            this.nome = nome;
            this.nascimento = nascimento;
            this.endereco = endereco;
            this.telefone = telefone;
            this.email = email;
    }
    
    public Cliente(){
        
    }
    
    
}
