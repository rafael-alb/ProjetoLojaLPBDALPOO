/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author Rafael
 */
    public class Produtos {
        
        public int cod_prod;
    
        public String descricao;
    
        public Date data_validade;
    
        public String estoque;
    
        public int idfk_dist;
    
        public float preco_venda;
        
        public float preco_custo;

    public int getCod_prod() {
        return cod_prod;
    }

    public void setCod_prod(int cod_prod) {
        this.cod_prod = cod_prod;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getData_validade() {
        return data_validade;
    }

    public void setData_validade(Date data_validade) {
        this.data_validade = data_validade;
    }

    public String getEstoque() {
        return estoque;
    }

    public void setEstoque(String estoque) {
        this.estoque = estoque;
    }

    public int getIdfk_dist() {
        return idfk_dist;
    }

    public void setIdfk_dist(int idfk_dist) {
        this.idfk_dist = idfk_dist;
    }

    public float getPreco_venda() {
        return preco_venda;
    }

    public void setPreco_venda(float preco_venda) {
        this.preco_venda = preco_venda;
    }

    public float getPreco_custo() {
        return preco_custo;
    }

    public void setPreco_custo(float preco_custo) {
        this.preco_custo = preco_custo;
    }
        
    public Produtos(Integer cod_prod, String descricao, Date data_validade, String estoque, Integer idfk_dist, Float preco_venda, Float preco_custo){
            this.cod_prod = cod_prod;
            this.descricao = descricao;
            this.data_validade = data_validade;
            this.estoque = estoque;
            this.idfk_dist = idfk_dist;
            this.preco_venda = preco_venda;
            this.preco_custo = preco_custo;
    }
    
    public Produtos(){
        
    }
    
    
}
