/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author Rafael
 */
public class Vendas {
    
    public int cod_vendas;
    public int idfk_clientes;
    public float total;
    public Date datahora;

    public int getCod_vendas() {
        return cod_vendas;
    }

    public void setCod_vendas(int cod_vendas) {
        this.cod_vendas = cod_vendas;
    }

    public int getIdfk_clientes() {
        return idfk_clientes;
    }

    public void setIdfk_clientes(int idfk_clientes) {
        this.idfk_clientes = idfk_clientes;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public Date getDatahora() {
        return datahora;
    }

    public void setDatahora(Date datahora) {
        this.datahora = datahora;
    }
    
    public Vendas(Integer cod_vendas, Integer idfk_clientes, Float total, Date datahora){
        this.cod_vendas = cod_vendas;
        this.idfk_clientes = idfk_clientes;
        this.total = total;
        this.datahora = datahora;
    }
    
    public Vendas(){
        
    }
    
    
}
