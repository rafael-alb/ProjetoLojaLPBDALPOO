package views;

import java.sql.*;
import conexao.Conexao;
import conversores.Conversor;
import models.Cliente;
import models.Distribuidores;
import models.ItensVenda;
import models.Produtos;
import dao.ClienteDAO;
import dao.DistribuidoresDAO;
import dao.ItensVendaDAO;
import dao.ProdutosDAO;
import dao.VendasDAO;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.format.DateTimeFormatter;
import java.util.List;
import models.Vendas;

/**
 *
 * @author Rafael
 */
public class Main {
            
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ParseException {
        Conexao conexao = new Conexao();
        conexao.criarConexao();
        
        Date date = new Date();  
         Timestamp ts=new Timestamp(date.getTime());  
        
        /*-------------------------DISTRIBUIDORES------------------------------------*/
        
        //inserção do distribuidor
        
        /*Distribuidores dist = new Distribuidores();
        dist.codigo = 1;
        dist.nome_fantasia = "Coca-Cola";
        dist.razao_social = "Coca-Cola Indústrias Ltda";
        dist.telefone = "12432434343";
        dist.email = "cocacola@gmail.com";
        DistribuidoresDAO distDAO = new DistribuidoresDAO();
        distDAO.inserirDistribuidor(dist);

        
        /*-------------------------------CLIENTES-----------------------------------*/
        
        //inserção de clientes no banco
        
        /*Cliente cliente = new Cliente();
        cliente.codigo = 5;
        cliente.nome = "Selton Mello";
        cliente.nascimento = Conversor.StringParaData("12/09/1993");
        cliente.endereco = "Rua 789";
        cliente.telefone = "12555555";
        cliente.email = "selton_mello@gmail.com";
        ClienteDAO cliDAO = new ClienteDAO();
        cliDAO.inserirCliente(cliente);*/
        
        //Seleção de clientes sem email
        
        /*ClienteDAO clDAO = new ClienteDAO(); 
        List<Cliente> c = clDAO.ListarCliente();
        
        for (int i = 0; i <= c.size()-1; i++)
         {
             System.out.println("-----------------------------------");
             System.out.print("Código: ");System.out.println(c.get(i).codigo);
             System.out.println("-----------------------------------");
             System.out.print("Nome: ");System.out.println(c.get(i).nome);
             System.out.println("-----------------------------------");
             System.out.print("Nascimento: ");System.out.println(c.get(i).nascimento);
             System.out.println("-----------------------------------");
             System.out.print("Endereço: ");System.out.println(c.get(i).endereco);
             System.out.println("-----------------------------------");
             System.out.print("Telefone: ");System.out.println(c.get(i).telefone);
             System.out.println("-----------------------------------");
             System.out.print("Email: ");System.out.println(c.get(i).email);
             System.out.println("-----------------------------------");
             System.out.println();
             System.out.println();
         }*/
        
        /*-------------------------------ITENS VENDA----------------------------------*/
        
        //inserção de itens da venda
        
       /*ItensVenda itve = new ItensVenda();
        Vendas ven = new Vendas();
        ven.cod_vendas = 10;
        ven.idfk_clientes = 10;
        ven.total = 9;
        ven.setDatahora(ts);
        Produtos p = new Produtos(3,"Coca Cola Zero 2.5L",Conversor.StringParaData("04/05/2021"),"110",1,11.99F,7.49F);
        itve.idfk_vendas = (ven);
        itve.idfk_produtos = (p);
        itve.quantidade = 1;
        itve.sub_total = itve.quantidade*itve.idfk_produtos.getPreco_venda();
        ItensVendaDAO itveDAO = new ItensVendaDAO();
        itveDAO.inserirItensVenda(itve);
        
       /*-------------------------------PRODUTOS----------------------------------*/
       
       //inserção de produtos
        
       /*Produtos pds = new Produtos();
        pds.cod_prod = 10;
        pds.descricao = "Coca Cola Zero 2.5L";
        pds.data_validade = Conversor.StringParaData("04/05/2021");
        pds.estoque = "110";
        pds.idfk_dist = 1;
        pds.preco_venda = 10.99F;
        pds.preco_custo = 7.49F;
        ProdutosDAO pdtDAO = new ProdutosDAO();
        pdtDAO.inserirProdutos(pds);*/
       
       //listagem de produtos vencidos
        
        /*ProdutosDAO pdtsDAO = new ProdutosDAO();
        List<Produtos> p = pdtsDAO.ListarProdutos();
        
        for (int i = 0; i <= p.size()-1; i++)
         {
             System.out.println("-----------------------------------");
             System.out.print("Código: ");System.out.println(p.get(i).cod_prod);
             System.out.println("-----------------------------------");
             System.out.print("Descrição: ");System.out.println(p.get(i).descricao);
             System.out.println("-----------------------------------");
             System.out.print("Data de validade: ");System.out.println(p.get(i).data_validade);
             System.out.println("-----------------------------------");
             System.out.print("Estoque: ");System.out.println(p.get(i).estoque);
             System.out.println("-----------------------------------");
             System.out.print("Código Distribuidor: ");System.out.println(p.get(i).idfk_dist);
             System.out.println("-----------------------------------");
             System.out.print("Preço de venda: ");System.out.println(p.get(i).preco_venda);
             System.out.println("-----------------------------------");
             System.out.print("Preço de custo: ");System.out.println(p.get(i).preco_custo);
             System.out.println("-----------------------------------");
             System.out.println();
             System.out.println();
         }*/
    
       /*-------------------------------VENDAS----------------------------------*/
       
       //inserção de vendas
        
         /*Vendas vnd = new Vendas();
         vnd.cod_vendas = 10;
         vnd.idfk_clientes = 5;
         vnd.total = 9;
         vnd.setDatahora(ts);
         VendasDAO vndDAO = new VendasDAO();
         vndDAO.inserirVendas(vnd);*/
        
         //Quantidade de vendas em 2020 listadas por cliente
         
        /*VendasDAO vndsDAO = new VendasDAO();
        List<Vendas> v = vndsDAO.ListarVendas();
        
        for (int i = 0; i <= v.size()-1; i++)
         {
             System.out.println("-----------------------------------");
             System.out.print("Código cliente: ");System.out.println(v.get(i).idfk_clientes);
             System.out.println("-----------------------------------");
             System.out.print("Quantidade vendas 2020: ");System.out.println(v.get(i).cod_vendas);
             System.out.println("-----------------------------------");
             System.out.println();
             System.out.println();
         }*/
        
        //Listagem de vendas contendo o valor total da mesma
        
        /*VendasDAO vndDAO = new VendasDAO();
        List<Vendas> vn = vndDAO.ListarVendasTotal();
        Conversor conversor = new Conversor();
        
        for (int i = 0; i <= vn.size()-1; i++)
         {
             System.out.println("-----------------------------------");
             System.out.print("Código da venda: ");System.out.println(vn.get(i).cod_vendas);
             System.out.println("-----------------------------------");
             System.out.print("Código cliente: ");System.out.println(vn.get(i).idfk_clientes);
             System.out.println("-----------------------------------");
             System.out.print("Total de vendas em preço: ");System.out.println(vn.get(i).total);
             System.out.println("-----------------------------------");
             System.out.println("Data e hora: "+conversor.DataHoraParaString(vn.get(i).getDatahora()));
             System.out.println("-----------------------------------");
             System.out.println();
             System.out.println();
         }*/
       
    }
   
    
}
